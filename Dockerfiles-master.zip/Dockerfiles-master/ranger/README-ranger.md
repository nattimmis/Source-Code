Apache Ranger
=============

http://ranger.apache.org/

Hadoop security adminitration console for ACL management across components and auditing.

Starts a standalone Ranger admin console and maps port 6080.

```
docker-compose up
```

or without `docker-compose`

```
make run
```

See [master GitHub repo](https://github.com/HariSekhon/Dockerfiles/) top level for a tonne of related technologies.
