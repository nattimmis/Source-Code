export GRADLE_HOME=/opt/gradle
export PATH=$PATH:$GRADLE_HOME/bin
