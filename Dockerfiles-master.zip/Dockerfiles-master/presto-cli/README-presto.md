Teradata's distribution of Presto SQL Client (by Facebook)
======================================================

http://www.teradata.com/products-and-services/Presto/Presto-Download

Teradata's distribution of Presto SQL Client.

See adjacent `presto` directory for the server docker image source and for all the Facebook Presto releases see the adjacent `presto-dev` directory.

Related Docker images can be found for many Open Source, Big Data and NoSQL technologies on [my DockerHub profile](https://hub.docker.com/r/harisekhon). The source for them all can be found in the [master Dockerfiles GitHub repo](https://github.com/HariSekhon/Dockerfiles/).
