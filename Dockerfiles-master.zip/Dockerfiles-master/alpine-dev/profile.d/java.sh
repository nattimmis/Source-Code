export JAVA_HOME=/usr/lib/jvm/default-jvm
