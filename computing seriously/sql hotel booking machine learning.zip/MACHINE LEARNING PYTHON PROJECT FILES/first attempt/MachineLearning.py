list = [15, 2, 97, 45764]
UserNumber = int(input("Number: "))
list.append(UserNumber)
print(UserNumber)
print(list)